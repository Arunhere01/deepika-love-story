
function next() {
    const name = document.getElementById('nameInput').value || "Deepika";
    alert("Shall we go on a ride of memories, " + name + "?");
    // You can implement redirection to album slides here
}
